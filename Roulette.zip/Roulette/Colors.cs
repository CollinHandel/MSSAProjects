﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette
{
    public enum Colors { G, R, B }
}
